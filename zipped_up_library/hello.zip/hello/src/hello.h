//
// Created by afy on 7/20/21.
//

#ifndef HELLO_HELLO_H
#define HELLO_HELLO_H


class hello {

};


#endif //HELLO_HELLO_H
